<?php

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$product = $_POST['product'] ?? '';
$price = $_POST['price'] ?? '';

if(!isset($_FILES['receipt'])){
    die("Нет файла");
}

if(!$product=="Проходка на сервер"){
    $product=("enterense to server");
}

// создаём папку
if(!is_dir("uploads")){
    mkdir("uploads");
}

$filename = time() . "_" . $_FILES['receipt']['name'];
$path = "uploads/" . $filename;

move_uploaded_file($_FILES['receipt']['tmp_name'], $path);

// JSON
$file = 'data.json';

if(file_exists($file)){
    $data = json_decode(file_get_contents($file), true);
} else {
    $data = ["data" => []];
}

// новый ключ
$max = 0;
foreach(array_keys($data['data']) as $key){
    if(preg_match('/cus(\d+)/', $key, $m)){
        $num = (int)$m[1];
        if($num > $max) $max = $num;
    }
}

$newKey = 'cus' . ($max + 1);

// сохраняем
$data['data'][$newKey] = [
    "name" => $name,
    "email" => $email,
    "product" => $product,
    "price" => $price,
    "receipt" => $path
];

file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

echo "OK";